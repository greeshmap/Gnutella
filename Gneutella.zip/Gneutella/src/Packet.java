import java.util.Arrays;

public class Packet {
	public int desID;
	public byte TTL,Hops;
	public int PayloadLength;
	public short[] payload;
	public final static short PING=(short)0x00;
	public final static short PONG=(short)0x01;
	public final static short QUERY=(short)0x80;
	public final static short QUERYHIT=(short)0x81;
	public String des;
	
	public final static int Ping_PayloadLength=0;
	public Packet(int desID,String des) {
		this.desID=desID;
		this.TTL=3;
		this.Hops=0;
		this.PayloadLength=0;
		this.payload=null;
		this.des=des;
	}
	
	
	int getdesID()
	{
		return this.desID;
	}
	void setdesID(short desID)
	{
		this.desID=desID;
	}
	byte getTTL()
	{
		return (byte) (this.TTL);
	}
	void setTTL(byte TTL)
	{
		this.TTL=TTL;
	}
	byte getHops()
	{
		return (byte) (this.Hops+1);
	}
	void setPayloadLength(int PayloadLength)
	{
		this.PayloadLength=PayloadLength;
	}
	int getPayloadLength()
	{
		return this.PayloadLength;
	}
	byte[] createPacket()
	 {
		byte[] bytes = new byte[4];
		for (int i = 0; i < 4; i++) {
		    bytes[i] = (byte)(this.desID >>> (i * 8));
		}
		byte[] newarray=Arrays.copyOf(bytes, 28);
		if(this.des=="PING")
		{
			newarray[16]=PING;
			newarray[19]=1;
		}
		else if(this.des=="PONG")
		{
			newarray[16]=PONG;
			newarray[19]=4;
		}
		else if(this.des=="QUERY"){
			newarray[16]=(byte) QUERY;
			newarray[19]=16;
		}
		else if(this.des=="QUERYHIT")
		{
			newarray[16]=(byte) QUERYHIT;
			newarray[19]=16;
		}
		newarray[17]=getTTL();
		newarray[18]=getHops();
		return newarray;
	 }
	
	

}
