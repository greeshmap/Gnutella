import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Servant{
	public static HashMap<Integer,Integer> hashMap=new HashMap<Integer,Integer>();
	static Scanner scan=new Scanner(System.in);
	public static ArrayList<String> fileCollection=new ArrayList<String>();
	public final static short QUERY=(short)0x80;
	public static void main(String[] args) throws UnknownHostException, IOException, InterruptedException
	{
		
		System.out.println("enter id ");
		int id=scan.nextInt();
		System.out.println("enter port number");
		int port=scan.nextInt();
		
		System.out.println("enter the file path");
		String filePath=scan.next();
		
		File folder = new File(filePath.trim());
		File[] fileList = folder.listFiles();

		    for (int i = 0; i < fileList.length; i++) {
		      if (fileList[i].isFile()) {
		    	  String fullname=fileList[i].getName();
		    	  fileCollection.add(fullname.substring(0,fullname.indexOf(".")));
		    }
		    }
		Connection con=new Connection(id,port,filePath);
		new Thread(con).start();
		Receivers r=new Receivers(port,id,hashMap);
		new Thread(r).start();
		System.out.println("Node:"+id+" is up and listeneing on port "+port);
		System.out.println("Connect to any other system? Yes/No?");
		String choice=scan.next();
		if(choice.toLowerCase().contains("yes"))
		{
			con.connect();
			Thread.sleep(2000);
			System.out.println("returned..");
			con.Query();
		}
		scan.close();
		
	   
	}

	

}
