
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

public class Connection implements Runnable{
	public int id;public int port;
	public final static short QUERY=(short)0x80;
	public final static short QUERYHIT=(short)0x81;
	public HashMap<Integer,Integer> hashMap=new HashMap<Integer,Integer>();
	public HashMap<Integer,String> queryMap=new HashMap<Integer,String>();
	public Receivers r=null;
	public ServerSocket welcomeSocket=null;
	static Scanner scan=new Scanner(System.in);
	public Servant servant=new Servant();String filePath;
	public Connection(int id, int port, String filePath) throws UnknownHostException, IOException {
		this.id=id;
		this.port=port;
		this.filePath=filePath;
		
	}
	
public void Query() throws IOException {
	 
		String requestId=new Integer(50).toString();
		System.out.println("Enter the file name");
		while (!scan.hasNext()) {
			  if (!scan.hasNext()) {
			    System.err.println("no more input");
			    System.exit(1);
			  }			}
		String fileName=scan.next();
		System.out.println(fileName);	
		if(servant.fileCollection.contains(fileName))
		{
			System.out.println(fileName+" is present in the local directory");
		}
		else
		{
			Packet p=new Packet(this.id,"QUERY");
			byte[] packetByteArrayQuery=p.createPacket();
			byte[] packetByteArrayQuery1=new byte[packetByteArrayQuery.length+packetByteArrayQuery[19]];
			String query=this.id +" "+fileName+" "+requestId+" "+3;
			for (Entry<Integer, Integer> entry : servant.hashMap.entrySet()) {
				 int idKey = entry.getKey();
				 int portValue = entry.getValue();
				 Socket clientSocket = new Socket("127.0.0.1",portValue);
				 queryMap.put(portValue, requestId);
				 DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream());
				 out.write(packetByteArrayQuery);
				
				 byte[] str=(this.id +" "+fileName+" "+requestId+" "+"3").getBytes();
				 out.write(str);
				 out.writeUTF(this.id +" "+fileName+" "+requestId+" "+"3");
				 System.out.println("sent Query to "+idKey);
				 clientSocket.close();
			}
		}
		
	}
	
	public void connect() throws IOException
	{
		System.out.println("enter the port number to connect to");
		int sendingPort = scan.nextInt();
		InetAddress receiverAddress = InetAddress.getByName("localhost"); 
		Socket clientSocket = new Socket(receiverAddress,sendingPort);
		DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream());
		out.writeUTF(this.id + " "+ this.port+"  GNUTELLA CONNECT/0.4\n\n");
		clientSocket.close();
		return;
	}
	@Override
	public void run() {
		ServerSocket serverSocket=null;Socket client=null;
		DataInputStream in=null;
		DataOutputStream out=null;
		try {
			serverSocket=new ServerSocket(this.port);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		while(true)
		{
			 Socket connectionSocket=null;
			 
			 try
			 {
				 connectionSocket = serverSocket.accept();
				 in= new DataInputStream(connectionSocket.getInputStream());
				
				 byte[] buffer1=new byte[27];
				 byte[] buffer2=new byte[18];
				 byte[] buffer3=new byte[20];
				 in.readFully(buffer1,0,26);
				 in.read(buffer2, 0, 18);
				 in.read(buffer3, 0,20);
				 
				 String s=new String(buffer1);
				 String s1=new String(buffer2);
				 if(s.contains("GNUTELLA CON"))
				 {
					 int id=Integer.parseInt(s.substring(0,s.indexOf(" ")).trim());
					 String temp=s.substring(s.indexOf(" ")).trim();
					 int  portNo=Integer.parseInt(temp.substring(0, temp.indexOf("  ")));
					 System.out.println("Connection requested by:"+id+"  PortNumber:"+portNo);
					 if(servant.hashMap.containsKey(id))
					 {
						 System.out.println("Connected already..");
						 continue;
					 }
					 else
					 {
						 servant.hashMap.put(id, portNo);
						 System.out.println("Number of neighbors:"+servant.hashMap.size());
						 System.out.println("Files List:"+servant.fileCollection);
						 client = new Socket("127.0.0.1",portNo);
						 out = new DataOutputStream(client.getOutputStream());
						 out.writeUTF(this.id + " "+ this.port+"  GNUTELLA OK/0.4\n\n"); 
					 }
					 
					 client.close();
				 }   
				 if(s.contains("OK"))
				 {
					 int id=Integer.parseInt(s.substring(0,s.indexOf(" ")).trim());
					 String temp=s.substring(s.indexOf(" ")).trim();
					 int  portNo=Integer.parseInt(temp.substring(0, temp.indexOf("  ")));
					 servant.hashMap.put(id,portNo);
					 r=new Receivers(id,portNo,servant.hashMap);
					 r.ping(id,portNo);
					 System.out.println("connected to:"+id+" portNumber:"+ portNo);
					 System.out.println("Number of neighbors:"+servant.hashMap.size());
					 System.out.println("Files List:"+servant.fileCollection);
				 }
				 
				 if(buffer1[16]==(byte)QUERY)
				 {
					 System.out.println("received query");
					 String query=new String(buffer3);
					 String[] query1=query.split(" ");
					 int id=Integer.parseInt(query1[0].trim());
					 String fileName=query1[1].trim();
					 String requestId=query1[2].trim();
					 int TTL=Integer.parseInt(query1[3].trim());
					 
					 queryMap.put(this.port, requestId);
					 
					 if(servant.fileCollection.contains(fileName))
					 {
						 System.out.println("There is a hit");
						 Socket cSocket = new Socket("127.0.0.1",connectionSocket.getLocalPort());
						 out = new DataOutputStream(cSocket.getOutputStream());
						 Packet p=new Packet(this.id,"QUERYHIT");
						 byte[] queryHit=p.createPacket();
						 out.write(queryHit);
						 byte[] str=(this.port+" "+requestId+" "+this.filePath).getBytes();
						 out.write(str);
						 cSocket.close();
					
					 }
					 else
					 {
						 Socket cSocket=null;
						DataOutputStream outs=null;
						 for (Entry<Integer, Integer> entry : servant.hashMap.entrySet()) {
							 int idKey = entry.getKey();
							 int portValue = entry.getValue();
							 cSocket = new Socket("127.0.0.1",portValue);
							 queryMap.put(portValue, requestId);
							  
							 if(buffer2[17]>1)
							 {
								 outs = new DataOutputStream(cSocket.getOutputStream());
								 Packet p=new Packet(this.id,"QUERY");
								 byte[] q=p.createPacket();
								 buffer2[17]=(byte) (buffer2[17]-1);
								 outs.write(buffer2);
								 byte[] str=(this.port+" "+requestId+" "+this.filePath).getBytes();
								 outs.write(str);
								 System.out.println("Forwarded Query to "+idKey);
							 }
							
							
						}
						cSocket.close();
					 }
					 
					
				 }
				 if(buffer1[16]==(byte)QUERYHIT)
				 {
					 String queryHit=new String(buffer2);
					 String[] queryHit1=queryHit.split(" ");
					 int portNumber=Integer.parseInt(queryHit1[0].trim());
					 String requestId=queryHit1[1].trim();
					 String filePath=queryHit1[2].trim();
					 if((queryMap.containsKey(portNumber)) && (queryMap.get(portNumber).equals(requestId)))
					 {
						 System.out.println("Received QueryHit "+filePath);
					 }
					 else
					 {
						 Socket cSockets=null;
							DataOutputStream outs=null;
							for (Entry<Integer, Integer> entry : servant.hashMap.entrySet()) {
							 int idKey = entry.getKey();
							 int portValue = entry.getValue();
							 cSockets = new Socket("127.0.0.1",portValue);
							 
							 if(buffer2[17]>1)
							 {
								 outs = new DataOutputStream(cSockets.getOutputStream());
								 buffer2[17]=(byte) (buffer2[17]-1);
								 outs.write(buffer2);
								 outs.write(buffer3);
								 System.out.println("Passed QueryHit to "+idKey);
							 }
							 
							 cSockets.close();
						}
					}
						
				 }
				 
			 }
			 catch(Exception e)
			 {
				 e.printStackTrace();
			 }
			
     }
		
		
	}
}


