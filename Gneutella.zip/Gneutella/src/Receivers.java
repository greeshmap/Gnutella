import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Map.Entry;

public class Receivers implements Runnable{
	public int port;public int id;
	public final static short PING=(short)0x00;
	public final static short PONG=(short)0x01;
	public final static short QUERY=(short)0x80;
	public final static short QUERYHIT=(short)0x81;
	HashMap<Integer,Integer> hashMap=new HashMap<Integer,Integer>(); 
	public DatagramSocket clientSocket=new DatagramSocket(null);;
	public Receivers(int port,int id,HashMap<Integer,Integer> hashMap) throws SocketException {
		this.port=port;
		this.id=id;
		this.hashMap=hashMap;
		try {
			clientSocket.setReuseAddress(true);
			clientSocket.bind(new InetSocketAddress("127.0.0.1",this.port));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		
		
		byte[] receiveData = new byte[1024]; 
		byte[] sendData = new byte[1024];
		while(true)
		{
			try
			{
				
				DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
				clientSocket.receive(receivePacket); 
				String sentence = new String( receivePacket.getData());  
				byte[] bytearray=new byte[1024];
				bytearray=sentence.getBytes();
				
				
				if(sentence.contains("GNUTELLA CONNECT"))
				{
					System.out.println("RECEIVED: " + sentence.trim());
					int id=Integer.parseInt(sentence.substring(0,sentence.indexOf(" ")));
					String portnumber=sentence.substring(sentence.indexOf(" "),sentence.lastIndexOf(" ")).trim();
					int port=Integer.parseInt(portnumber.substring(0, portnumber.indexOf("  ")));
					hashMap.put(id,port);
					
					InetAddress IPAddress = receivePacket.getAddress();  
					int recivedPort = receivePacket.getPort();     
					String replySentence =this.id + " "+ clientSocket.getLocalPort() + " GNUTELLA OK";
					sendData = replySentence.getBytes();   
					DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, recivedPort);
					clientSocket.send(sendPacket);
				}
				else if(sentence.contains("GNUTELLA OK"))
				{
					System.out.println("RECEIVED: " + sentence.trim());
					int id=Integer.parseInt(sentence.substring(0,sentence.indexOf(" ")));
					String portnumber=sentence.substring(sentence.indexOf(" "),sentence.lastIndexOf(" ")).trim();
					int port=Integer.parseInt(portnumber.substring(0, portnumber.indexOf(" ")));
					while(true)
					{
						Thread.sleep(10000);
						Packet p=new Packet(this.id,"PING");
						byte[] packetByteArray=new byte[50];
						packetByteArray=p.createPacket();
						packetByteArray[24]=5;
						
						for (Entry<Integer, Integer> entry : this.hashMap.entrySet()) {
						    int idKey = entry.getKey();
						    int portValue = entry.getValue();
							InetAddress receiverAddress = receivePacket.getAddress();
							DatagramPacket packet = new DatagramPacket(packetByteArray, packetByteArray.length, receiverAddress, portValue);
							clientSocket.send(packet);
							//System.out.println("Sent ping to "+portValue);
							
						}
					}
					
				}
				else if(bytearray[16]==PING)
				{
					//System.out.println("Received ping");
					Packet p=new Packet(this.id,"PONG");
					byte[] packetByteArray=p.createPacket();
					InetAddress receiverAddress = receivePacket.getAddress();
					int portValue = receivePacket.getPort();
					DatagramPacket pongPacket = new DatagramPacket(packetByteArray, packetByteArray.length, receiverAddress, portValue);
					clientSocket.send(pongPacket);
					//System.out.println("sent pong back to"+portValue);
					
					for (Entry<Integer, Integer> entry : this.hashMap.entrySet()) {
					    int Key = entry.getKey();
					    int Value = entry.getValue();
					    packetByteArray[17]=(byte) (packetByteArray[17]-1);
					    if(packetByteArray[17]>0)
					    {
						DatagramPacket fwdPacket = new DatagramPacket(packetByteArray, packetByteArray.length, receiverAddress, Value);
						clientSocket.send(fwdPacket);
						}
					}
				}
				else if(bytearray[16]==(byte)PONG)
				{
					int id=bytearray[0];
					if(!hashMap.containsKey(bytearray[0]))
						 hashMap.put(id,clientSocket.getLocalPort());
					
					
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
	
	public void ping(int id,int portNo) throws UnknownHostException, IOException, InterruptedException {
		
		
		InetAddress IPAddress = InetAddress.getByName("localhost"); 
		byte[] sendData = new byte[1024];   
		String sentence = id + " "+ portNo+"  GNUTELLA OK/0.4\n\n";
		sendData = sentence.getBytes();  
		DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress,portNo); 
		clientSocket.send(sendPacket); 
		
	}
	
	

	public void connect() throws UnknownHostException, IOException, InterruptedException {
		System.out.println("enter the port number to connect to");
		Scanner scan = new Scanner(System.in);
		int sendingPort = scan.nextInt();
		InetAddress IPAddress = InetAddress.getByName("localhost"); 
		byte[] sendData = new byte[1024];    
		String sentence = this.id + " "+ clientSocket.getLocalPort()+"  GNUTELLA CONNECT/0.4\n\n";
		sendData = sentence.getBytes();  
		DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress,sendingPort); 
		clientSocket.send(sendPacket);
        scan.close();
	}

	
}
